import React from 'react'

const AddEmployee = () => {
  return (
    <div>AddEmployee</div>
  )
}

export default AddEmployee