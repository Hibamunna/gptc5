import React from 'react'
import App from '../App'
import { AppBar, Toolbar } from '@mui/material'

const Navbarr = () => {
  return (
    <div>
        <AppBar>
            <Toolbar>
                <Button variant='h4'>Home</Button>
            </Toolbar>
        </AppBar>
    </div>
  )
}

export default Navbarr